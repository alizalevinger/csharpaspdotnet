﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Confirmation : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
        Reservation confirmReservation =  new Reservation();
          confirmReservation.Name = ((Reservation)Session["Reservation"]).Name;
          confirmReservation.Email = ((Reservation)Session["Reservation"]).Email;
          confirmReservation.ArrivalDate = ((Reservation)Session["Reservation"]).ArrivalDate;
          confirmReservation.DepartureDate = ((Reservation)Session["Reservation"]).DepartureDate;
          confirmReservation.NoOfAdults = ((Reservation)Session["Reservation"]).NoOfAdults;
          confirmReservation.NoOfChildren = ((Reservation)Session["Reservation"]).NoOfChildren;
          confirmReservation.RoomType = ((Reservation)Session["Reservation"]).RoomType;
          confirmReservation.BedType = ((Reservation)Session["Reservation"]).BedType;
          confirmReservation.Smoking = ((Reservation)Session["Reservation"]).Smoking;
          confirmReservation.SpecialRequests = ((Reservation)Session["Reservation"]).SpecialRequests;
          lblName.Text = confirmReservation.Name;
          lblEmail.Text = confirmReservation.Email;
          lblArrivalDate.Text = confirmReservation.ArrivalDate.ToShortDateString(); 
          lblDepartureDate.Text = confirmReservation.DepartureDate.ToShortDateString();
          lblNoOfAdults.Text= confirmReservation.NoOfAdults.ToString();
          lblNoOfChildren.Text = confirmReservation.NoOfChildren.ToString();
          lblRoomType.Text = confirmReservation.RoomType;
          lblBedType.Text = confirmReservation.BedType;

          if (confirmReservation.Smoking == true)
              lblSmoking.Text = "Yes";
          else 
              lblSmoking.Text = "No";


          if (confirmReservation.SpecialRequests != null)
              lblSpecialRequests.Text = confirmReservation.SpecialRequests;
          else
              lblSpecialRequests.Text = "None";


        
        


    }

    protected void btnConfirm_Click(object sender, EventArgs e)
    {
        HttpCookie nameCookie = new HttpCookie("Name", lblName.Text);
        nameCookie.Expires = DateTime.Today.AddMonths(6);
        Response.Cookies.Add(nameCookie);
        HttpCookie emailCookie = new HttpCookie("Email", lblEmail.Text);
        emailCookie.Expires = DateTime.Today.AddMonths(6);
        Response.Cookies.Add(emailCookie);
        lblMessage.Text = "Thank you for your request.<br />" +
                          "We will get back to you within 24 hours.";
    }
}