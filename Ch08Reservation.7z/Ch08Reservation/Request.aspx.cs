﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Request : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Reservation reservation = (Reservation) Session["Reservation"];     
            
            ddlAdults.Items.Add("1");
            ddlAdults.Items.Add("2");
            ddlAdults.Items.Add("3");
            ddlAdults.Items.Add("4");

            ddlChildren.Items.Add("0");
            ddlChildren.Items.Add("1");
            ddlChildren.Items.Add("2");
            ddlChildren.Items.Add("3");
            ddlChildren.Items.Add("4");

            rdoStandard.Checked = true;
            rdoKing.Checked = true;

            rvArrival.MinimumValue = DateTime.Today.ToShortDateString();
            rvArrival.MaximumValue = DateTime.Today.AddMonths(6).ToShortDateString();

            if (Request.Cookies["Name"] != null)
                txtName.Text = Request.Cookies["Name"].Value;
        
            if(Request.Cookies["Email"] != null)
                txtEmail.Text=Request.Cookies["Email"].Value;

            if(reservation != null)
            {
                txtArrivalDate.Text = reservation.ArrivalDate.ToShortDateString();
                txtNights.Text = reservation.DepartureDate.Subtract(reservation.ArrivalDate).Days.ToString();
                ddlAdults.SelectedValue = ((Reservation)Session["Reservation"]).NoOfAdults.ToString();
        
                ddlChildren.SelectedValue = ((Reservation)Session["Reservation"]).NoOfChildren.ToString();
            
                if (reservation.RoomType == "Business")
                    rdoBusiness.Checked = true;
                else if (((Reservation)Session["Reservation"]).RoomType == "Suite")
                    rdoSuite.Checked = true;
                else if (((Reservation)Session["Reservation"]).RoomType == "Standard")
                    rdoStandard.Checked = true;

            if (reservation.BedType == "King")
                rdoKing.Checked = true;
            else
                rdoDouble.Checked = true;

            if (reservation.Smoking == true)
                chkSmoking.Checked = true;
            else
                chkSmoking.Checked = false;

            if (reservation.SpecialRequests != null)
                txtSpecialRequests.Text = ((Reservation)Session["Reservation"]).SpecialRequests;
            txtName.Text = reservation.Name;

            txtEmail.Text= reservation.Email; 
                
            }
    
            
    }
    }

    protected void ibtnCalendar_Click(object sender, ImageClickEventArgs e)
    {
        ibtnCalendar.Visible = false;
        clnArrival.Visible = true;
    }

    protected void clnArrival_SelectionChanged(object sender, EventArgs e)
    {
        txtArrivalDate.Text = clnArrival.SelectedDate.Month.ToString() + "/" +
                              clnArrival.SelectedDate.Day.ToString() + "/" +
                              clnArrival.SelectedDate.Year.ToString();
        clnArrival.Visible = false;
        ibtnCalendar.Visible = true;
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        Reservation reservation = new Reservation();
        
        reservation.ArrivalDate = Convert.ToDateTime(txtArrivalDate.Text);
        reservation.DepartureDate = reservation.ArrivalDate.AddDays(Convert.ToInt32(txtNights.Text));
        reservation.NoOfAdults = Convert.ToInt32(ddlAdults.SelectedValue);
        reservation.NoOfChildren = Convert.ToInt32(ddlChildren.SelectedValue);
        if (rdoBusiness.Checked==true)
             reservation.RoomType = "Business";
        else if(rdoSuite.Checked==true)
            reservation.RoomType = "Suite";
        else if (rdoStandard.Checked==true)
            reservation.RoomType = "Standard";


        if (rdoKing.Checked==true)
            reservation.BedType="King";
        else if (rdoDouble.Checked==true)
            reservation.BedType="Double Double";
    
        if (chkSmoking.Checked==true)
            reservation.Smoking=true;
        else 
            reservation.Smoking=false;

        reservation.SpecialRequests = txtSpecialRequests.Text;
        reservation.Name = txtName.Text;
        reservation.Email=txtEmail.Text;

        Session["Reservation"] = reservation;
        Response.Redirect("Confirmation.aspx");
    
    }

    protected void btnClear_Click(object sender, EventArgs e)
    {
        txtArrivalDate.Text = "mm/dd/yyyy";
        txtNights.Text = "";
        ddlAdults.SelectedIndex = -1;
        ddlChildren.SelectedIndex = -1;
        rdoStandard.Checked = true;
        rdoKing.Checked = true;
        chkSmoking.Checked = false;
        txtSpecialRequests.Text = "";
        txtName.Text = "";
        txtEmail.Text = "";
        
    }
}